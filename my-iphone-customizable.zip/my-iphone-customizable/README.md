# My customizable iPhone 13

This is a single-file website. All styling and interactions are inside `index.html`, so you won't accidentally miss a CSS or JavaScript file.

## Preview
Open `index.html` in a modern browser (Safari, Chrome, Edge, Firefox). If your phone's file preview shows plain text or an unstyled page, use GitHub Pages instead.

## Customize
The panel beside the phone lets you:
- Set the phone owner's name
- Change accent and wallpaper colors
- Upload a wallpaper image
- Change the lock-screen notification

Inside the simulated phone, open **Settings** to rename apps. Notes and design settings are saved in the current browser using local storage.

## Publish free with GitHub Pages
1. Create a public GitHub repository named `my-iphone`.
2. Upload `index.html` to the repository's root (not inside another folder).
3. Go to Settings → Pages.
4. Choose Deploy from a branch, branch `main`, folder `/(root)`, then Save.
5. Open the published URL shown on the Pages settings screen.

This is a fictional front-end simulation, not Apple's iOS. The Safari app is a demo screen and opens entered sites in a new tab. Use fictional data; don't publish private messages or personal information.
